module.exports = [
    './gulp/tasks/clean',
    './gulp/tasks/copy',
    './gulp/tasks/pug',
    './gulp/tasks/scripts',
    './gulp/tasks/serve',
    './gulp/tasks/styles',
    './gulp/tasks/watch'
];